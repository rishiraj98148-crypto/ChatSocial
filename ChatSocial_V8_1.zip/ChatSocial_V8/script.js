import{initializeApp}from"https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";import{getAuth,onAuthStateChanged,createUserWithEmailAndPassword,signInWithEmailAndPassword,updateProfile,signOut}from"https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";import{getFirestore,collection,doc,setDoc,addDoc,query,orderBy,onSnapshot,serverTimestamp,updateDoc}from"https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";import{firebaseConfig}from"./firebase-config.js";
const $=id=>document.getElementById(id),app=initializeApp(firebaseConfig),auth=getAuth(app),db=getFirestore(app);let user=null,friend=null,unsubMessages=null,unsubUsers=null,localPhoto=localStorage.getItem("csV7photo")||"";const toast=s=>{$("toast").textContent=s;$('toast').style.display="block";setTimeout(()=>$('toast').style.display="none",1800)},initials=n=>(n||"U").trim()[0].toUpperCase(),safe=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));function cid(a,b){return[a,b].sort().join("_")}
async function signup(){try{let n=$("displayName").value.trim(),e=$("email").value.trim(),p=$("password").value;if(!n)return $("authMsg").textContent="Enter your name";if(p.length<6)return $("authMsg").textContent="Password must be 6+ characters";let c=await createUserWithEmailAndPassword(auth,e,p);await updateProfile(c.user,{displayName:n});await setDoc(doc(db,"users",c.user.uid),{uid:c.user.uid,name:n,email:e,bio:"",photoUrl:"",online:true,updatedAt:serverTimestamp()})}catch(e){$("authMsg").textContent=e.message}}
async function login(){try{await signInWithEmailAndPassword(auth,$("email").value.trim(),$("password").value)}catch(e){$("authMsg").textContent=e.message}}
function renderMyPhoto(){if(localPhoto){$("myAvatar").innerHTML=`<img src="${localPhoto}">`;$("profilePhoto").src=localPhoto}else{$("myAvatar").textContent=initials(user?.displayName);$("profilePhoto").src=`data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Crect width='100%25' height='100%25' fill='%235b5cf0'/%3E%3Ctext x='50%25' y='58%25' text-anchor='middle' font-size='55' fill='white'%3E${initials(user?.displayName)}%3C/text%3E%3C/svg%3E`}}
function listenUsers(){unsubUsers?.();unsubUsers=onSnapshot(query(collection(db,"users"),orderBy("name")),s=>{let q=$("search").value.toLowerCase();$("users").innerHTML="";s.docs.map(x=>x.data()).filter(u=>u.uid!==user.uid&&u.name.toLowerCase().includes(q)).forEach(u=>{let b=document.createElement("button");b.className="user";b.innerHTML=`<div class="avatar sm">${u.photoUrl?`<img src="${u.photoUrl}">`:initials(u.name)}</div><div><b>${safe(u.name)}</b><span>${u.online?"🟢 Online":"⚪ Offline"}</span></div>`;b.onclick=()=>selectFriend(u);$("users").appendChild(b)})})}
function selectFriend(u){friend=u;$("fn").textContent=u.name;$("fa").innerHTML=u.photoUrl?`<img src="${u.photoUrl}">`:initials(u.name);$("fs").textContent=u.online?"● Online":"● Offline";$("msg").disabled=$("send").disabled=false;unsubMessages?.();unsubMessages=onSnapshot(query(collection(db,"conversations",cid(user.uid,u.uid),"messages"),orderBy("createdAt")),s=>{let m=$("messages");m.innerHTML="";s.forEach(x=>m.appendChild(renderV8Message(x.data(),x.id)));m.scrollTop=m.scrollHeight})}
async function send(){if(!friend)return;const text=$("msg").value.trim();if(!text&&!pendingAttachment)return;try{const data={senderId:user.uid,receiverId:friend.uid,text,createdAt:serverTimestamp()};if(pendingAttachment?.dataUrl)data.imageData=pendingAttachment.dataUrl;if(pendingAttachment?.name)data.fileName=pendingAttachment.name;await addDoc(collection(db,"conversations",cid(user.uid,friend.uid),"messages"),data);$("msg").value="";pendingAttachment=null;$("attachmentPreview").classList.add("hidden");$("attachmentPreview").innerHTML=""}catch(e){toast("Send failed: "+e.message)}}

async function saveProfile(){let n=$("editName").value.trim(),bio=$("editBio").value.trim(),url=$("editPhotoUrl").value.trim();if(!n)return;try{await updateProfile(user,{displayName:n});await setDoc(doc(db,"users",user.uid),{name:n,bio,photoUrl:url,updatedAt:serverTimestamp()},{merge:true});$("myName").textContent=n;if(url){localPhoto=url;localStorage.setItem("csV7photo",url)}renderMyPhoto();$("profileModal").classList.add("hidden");toast("Profile saved")}catch(e){$("profileMsg").textContent=e.message}}
$("signup").onclick=signup;$("login").onclick=login;$("logout").onclick=()=>signOut(auth);$("send").onclick=send;$("msg").onkeydown=e=>e.key==="Enter"&&send();$("theme").onclick=()=>document.body.classList.toggle("dark");$("search").oninput=listenUsers;$("call").onclick=()=>toast("Voice call UI ready — WebRTC backend needed");$("video").onclick=()=>toast("Video call UI ready — WebRTC backend needed");$("profileBtn").onclick=()=>{$("editName").value=user.displayName||"";$("editBio").value="";$("editPhotoUrl").value=localPhoto.startsWith("data:")?"":localPhoto;$("profileModal").classList.remove("hidden");renderMyPhoto()};$("profileOpen").onclick=()=>$("profileBtn").click();$("closeProfile").onclick=()=>$("profileModal").classList.add("hidden");$("saveProfile").onclick=saveProfile;$("photoInput").onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{localPhoto=r.result;localStorage.setItem("csV7photo",localPhoto);renderMyPhoto();toast("Photo saved on this device")};r.readAsDataURL(f)};
onAuthStateChanged(auth,async u=>{user=u;if(u){$("auth").classList.add("hidden");$("app").classList.remove("hidden");$("myName").textContent=u.displayName||"User";renderMyPhoto();listenUsers();await setDoc(doc(db,"users",u.uid),{uid:u.uid,name:u.displayName||u.email,email:u.email,online:true,updatedAt:serverTimestamp()},{merge:true})}else{$("auth").classList.remove("hidden");$("app").classList.add("hidden")}});

// V8 enhancements: reactions, edit/delete, image attachment and notification permission.
let pendingAttachment=null;
function renderV8Message(d,id){const e=document.createElement("div");e.className="bubble "+(d.senderId===user.uid?"mine":"");let body="";if(d.deleted)body="<i>This message was deleted.</i>";else{if(d.text)body+=`<div>${safe(d.text)}</div>`;if(d.imageData)body+=`<img class="chatImage" src="${d.imageData}" alt="Shared image">`;if(d.fileName&&!d.imageData)body+=`<div>📎 ${safe(d.fileName)}</div>`}const time=d.createdAt?.toDate?d.createdAt.toDate().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):"sending…";body+=`<span class="time">${time}${d.edited?" (edited)":""}</span>`;if(d.senderId===user.uid&&!d.deleted)body+=`<div class="actions"><button data-edit="${id}">✏️ Edit</button><button data-delete="${id}">🗑️ Delete</button></div>`;if(!d.deleted)body+=`<div class="reactionBar"><button data-react="${id}" data-emoji="👍">👍</button><button data-react="${id}" data-emoji="❤️">❤️</button><button data-react="${id}" data-emoji="😂">😂</button><span>${safe(d.reaction||"")}</span></div>`;e.innerHTML=body;e.querySelectorAll("[data-edit]").forEach(b=>b.onclick=async()=>{const v=prompt("Edit message",d.text||"");if(v===null)return;try{await updateDoc(doc(db,"conversations",cid(user.uid,friend.uid),"messages",id),{text:v,edited:true})}catch(err){toast("Edit failed: "+err.message)}});e.querySelectorAll("[data-delete]").forEach(b=>b.onclick=async()=>{if(!confirm("Delete this message?"))return;try{await updateDoc(doc(db,"conversations",cid(user.uid,friend.uid),"messages",id),{deleted:true,text:"",imageData:"",fileName:""})}catch(err){toast("Delete failed: "+err.message)}});e.querySelectorAll("[data-react]").forEach(b=>b.onclick=async()=>{try{await updateDoc(doc(db,"conversations",cid(user.uid,friend.uid),"messages",id),{reaction:b.dataset.emoji})}catch(err){toast("Reaction failed: "+err.message)}});return e}
$("attach").onclick=()=>$("fileInput").click();
async function compressImage(file){
  if(file.size>12*1024*1024)throw new Error("Image is over 12 MB. Choose a smaller original image.");
  const sourceUrl=URL.createObjectURL(file);
  try{
    const img=new Image();
    await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(new Error("Could not open this image."));img.src=sourceUrl});
    let scale=Math.min(1,1280/Math.max(img.naturalWidth,img.naturalHeight));
    for(let pass=0;pass<8;pass++){
      const canvas=document.createElement("canvas");
      canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));
      canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
      const ctx=canvas.getContext("2d");ctx.fillStyle="#ffffff";ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
      for(const quality of [0.82,0.72,0.62,0.52,0.42,0.32]){
        const blob=await new Promise(resolve=>canvas.toBlob(resolve,"image/jpeg",quality));
        if(blob&&blob.size<=120000){
          const dataUrl=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(new Error("Could not read compressed image."));r.readAsDataURL(blob)});
          return {dataUrl,size:blob.size,width:canvas.width,height:canvas.height};
        }
      }
      scale*=0.78;
      if(Math.min(img.naturalWidth,img.naturalHeight)*scale<320)break;
    }
    throw new Error("This image cannot be compressed enough. Try cropping it or choosing a smaller image.");
  }finally{URL.revokeObjectURL(sourceUrl)}
}
$("fileInput").onchange=async e=>{
  const f=e.target.files?.[0];if(!f)return;e.target.value="";
  if(!f.type.startsWith("image/")){toast("Choose an image file");return}
  const box=$("attachmentPreview");box.classList.remove("hidden");box.textContent="Compressing image…";
  try{
    const result=await compressImage(f);
    pendingAttachment={dataUrl:result.dataUrl,name:f.name.replace(/\.[^.]+$/,".jpg")};
    box.innerHTML=`<img src="${result.dataUrl}" alt="Compressed image preview"><span>${safe(f.name)}<br><small>${(f.size/1024).toFixed(0)} KB → ${(result.size/1024).toFixed(0)} KB · ${result.width}×${result.height}</small></span> <button id="clearAttachment">✕</button>`;
    $("clearAttachment").onclick=()=>{pendingAttachment=null;box.classList.add("hidden");box.innerHTML=""};
  }catch(err){pendingAttachment=null;box.classList.add("hidden");box.innerHTML="";toast(err.message||"Image compression failed")}
};
$("voice").onclick=()=>toast("Voice-message button is ready; recording backend is not connected yet.");
const notificationButton=document.createElement("button");notificationButton.textContent="🔔 Notifications";notificationButton.onclick=async()=>{if(!("Notification" in window)){toast("Browser notifications are not supported");return}const permission=await Notification.requestPermission();toast(permission==="granted"?"Browser notifications enabled":"Notifications not enabled")};document.querySelector(".side").insertBefore(notificationButton,$("logout"));
