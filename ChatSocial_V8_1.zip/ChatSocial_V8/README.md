# ChatSocial V8.1 — Automatic Image Compression
Developer: Rishi Raj Yadav

Upgrade from ChatSocial V7. Features: Firebase Auth and Firestore real-time text chat, profile/name/bio, user search, dark mode, image attachment preview with automatic JPEG compression (resizes and compresses selected images to about 120 KB or less), message reactions (👍 ❤️ 😂), edit/delete own messages, voice-message UI placeholder, browser notification permission button, mobile responsive UI.

Limitations: Image messages are embedded as small data URLs in Firestore (compressed to about 120 KB or less before embedding); production should use Firebase Storage. Voice recording and true background push notifications are not implemented. FCM/service worker is needed for push notifications; WebRTC/signaling is needed for real voice/video calls. Review Firestore rules before production.
Firebase project: chatsocial-ab5d4.


Image compression: select an image (up to 12 MB original); the browser resizes it to a maximum 1280 px edge and converts it to JPEG at adjusted quality/resolution to keep the compressed image near or below 120 KB. Transparent images are flattened on white; animated images are reduced to a still image. If compression cannot reach the target, the app shows an error. This remains a demo approach: large-scale image sharing should use Firebase Storage.
