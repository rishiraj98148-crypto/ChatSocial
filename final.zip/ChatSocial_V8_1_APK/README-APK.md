# ChatSocial V8.1 — Android APK build

This is the web source plus a Capacitor Android wrapper and GitHub Actions workflow. It is not a prebuilt APK.

## Build from a phone using GitHub
1. Extract this ZIP.
2. Upload all files and folders inside this project to the root of a GitHub repository (keep `.github/workflows/build-apk.yml`).
3. Open the repository's **Actions** tab.
4. Choose **Build ChatSocial APK** → **Run workflow**. If asked, select the `main` branch.
5. Wait for the green check mark. Open the successful run and download the `ChatSocial-debug-apk` artifact.
6. Extract the artifact ZIP on your phone, then tap `app-debug.apk` to install. Allow installation from that source if Android asks.
7. Install the same APK on both phones. Create/use two different ChatSocial accounts and connect both to the internet to test real-time chat.

## Important
- The app uses the Firebase configuration in `firebase-config.js`; keep the Firebase Auth and Firestore project enabled.
- The current Firestore rules are demo-friendly and should be secured before public release.
- The current project uses Firestore for small image data; it is not a substitute for Firebase Storage for production image sharing.
- Voice call/video call buttons, push notifications, and voice-message controls may be UI/demo features unless their underlying services are separately implemented.
- This workflow builds a **debug APK**, suitable for testing, not a Play Store release APK/AAB.
